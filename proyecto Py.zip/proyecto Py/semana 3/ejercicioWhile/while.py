
print("*---------- MAIN MENU ----------*")
print("--------------------------------")

print("\n Choice an option:")
opc = input(" 1 - Login\n 2 - Registrarse\n 3 - Salir\n")

